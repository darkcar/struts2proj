package com.frank.web.action;

import com.opensymphony.xwork2.ActionSupport;

public class DemoAction extends ActionSupport {
	public String request_uri() {
		return SUCCESS;
	}
}	
